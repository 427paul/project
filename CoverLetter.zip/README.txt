#1.
pip install django pandas requests selenium beautifulsoup4 PyPDF2 webdriver-manager

or 

pip install -r requirements.txt


#2.
python manage.py runserver

#3.
http://127.0.0.1:8000/